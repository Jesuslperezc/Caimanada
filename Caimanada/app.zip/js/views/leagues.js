import { getAllLeagues, getActiveLeague, createLeague, setActiveLeague, deleteLeague, updateLeague } from '../db/repositories/leagues.js';
import { getTeamsByLeague } from '../db/repositories/teams.js';
import { getPlayersByTeam } from '../db/repositories/players.js'; 
import { MatchEventRepository } from '../db/repositories/matchEvent.js'; 
import { getMatchesByLeague, bulkInsertFullMatches } from '../db/repositories/matches.js';
import { generateLeagueFixture, generateEliminationBracket } from '../utils/fixtureGenerator.js';
import { renderLeagueStatsChart } from '../components/statsChart.js';
import { startQRScanner, stopQRScanner, buildQRPayload } from '../utils/qr.js';
import { handleImportData, exportLeagueToJson, importLeagueFromJsonFile } from '../utils/export-import.js';
import { AlertService } from '../components/alert.js'; 
import { getMaxPlayersForSport } from '../utils/sport-terms.js';

const SPORT_DISPLAY_NAMES = {
  futbol_sala: 'Futbolito / Futsal', futbol_campo: 'Fútbol Campo', basketball: 'Baloncesto',
  baseball: 'Béisbol', kickingball: 'Kickingball', volleyball: 'Voleibol',
  padel: 'Pádel', ping_pong: 'Ping-Pong', ajedrez: 'Ajedrez'
};

function getActiveSport() { return localStorage.getItem('active_sport_id') || 'futbol_sala'; }
function escapeHTML(str) {
  if (!str) return '';
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}

export async function renderLeaguesView() {
  const container = document.getElementById('leagues-section');
  if (!container) return;
  container.innerHTML = `<loading-state message="Cargando ligas..."></loading-state>`;
  try {
    const allLeagues = await getAllLeagues();
    const activeSport = getActiveSport();
    const leagues = allLeagues.filter(league => league.sport === activeSport);
    const activeLeague = await getActiveLeague();
    
    container.innerHTML = `
      <header class="leagues-header">
        <div>
          <h1 class="view-title">Gestión de Ligas</h1>
          <p class="view-subtitle">Crea, administra y activa los torneos de Caimanada</p>
        </div>
        <div class="qr-display-box">
          <button id="btn-import-league" class="btn btn--secondary"><i class="fa-solid fa-cloud-arrow-down"></i> Importar Liga</button>
          <button id="btn-open-create-modal" class="btn btn--primary"><i class="fa-solid fa-plus"></i> Crear Nueva Liga</button>
        </div>
      </header>
      <div id="league-modal" class="modal-overlay is-hidden">
        <div class="modal-card">
          <h2 id="modal-title" class="modal-card__title">Crear Liga</h2>
          <form id="league-form">
            <input type="hidden" id="league-id" />
            <div class="form-group">
              <label class="form-group__label">Nombre de la Liga *</label>
              <input type="text" id="league-name" required placeholder="Ej: Torneo Verano 2026" class="form-control" />
            </div>
            <div class="form-grid-2">
              <div class="form-group">
                <label class="form-group__label">Deporte *</label>
                <select id="league-sport" required class="form-control">
                  <option value="futbol_sala">Futbolito / Futsal</option>
                  <option value="futbol_campo">Fútbol Campo</option>
                  <option value="basketball">Baloncesto</option>
                  <option value="baseball">Béisbol</option>
                  <option value="kickingball">Kickingball</option>
                  <option value="volleyball">Voleibol</option>
                  <option value="padel">Pádel</option>
                  <option value="ping_pong">Ping-Pong</option>
                  <option value="ajedrez">Ajedrez</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-group__label">Temporada *</label>
                <input type="text" id="league-season" required placeholder="Ej: 2026-I" class="form-control" />
              </div>
            </div>
            <div class="form-group">
              <label class="form-group__label">Modalidad *</label>
              <select id="league-mode" required class="form-control">
                <option value="Liga - Una vuelta">Liga (Todos contra todos - Una vuelta)</option>
                <option value="Liga - Ida y vuelta">Liga (Todos contra todos - Ida y vuelta)</option>
                <option value="Eliminación directa - 4 equipos">Eliminación directa (4 equipos)</option>
                <option value="Eliminación directa - 8 equipos">Eliminación directa (8 equipos)</option>
                <option value="Eliminación directa - 16 equipos">Eliminación directa (16 equipos)</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-group__label">Duración estimada (días) *</label>
              <input type="number" id="league-duration" min="1" value="7" required class="form-control" />
            </div>
            <div class="form-group form-group--last">
              <label class="form-group__label">Descripción (Opcional)</label>
              <textarea id="league-description" rows="2" placeholder="Reglas especiales, sede, etc." class="form-control"></textarea>
            </div>
            <div class="modal-actions">
              <button type="button" id="btn-close-modal" class="btn btn--secondary">Cancelar</button>
              <button type="submit" class="btn btn--primary">Guardar Liga</button>
            </div>
          </form>
        </div>
      </div>
      <div id="leagues-grid" class="leagues-grid"></div>
      <div id="league-stats-container" style="margin-top: 2rem;"></div>
    `;
    document.getElementById('btn-import-league')?.addEventListener('click', () => { openImportLeagueModal(); });
    await renderLeaguesCards(leagues, activeLeague);
    await renderLeagueChartSection(leagues);
    setupModalEvents(leagues);
  } catch (error) {
    console.error('Error al renderizar ligas:', error);
    container.innerHTML = ''; 
    const errComp = document.createElement('error-state');
    errComp.setError('Hubo un problema al cargar las ligas.', () => renderLeaguesView());
    container.appendChild(errComp);
  }
}

async function renderLeagueChartSection(leagues) {
  const statsContainer = document.getElementById('league-stats-container');
  if (!statsContainer) return;
  if (leagues.length === 0) { statsContainer.innerHTML = ''; return; }
  const leaguesDataWithTopWins = await Promise.all(leagues.map(async (league) => {
    const teams = await getTeamsByLeague(league.id);
    const matches = await getMatchesByLeague(league.id);
    const winsMap = {};
    teams.forEach(t => { winsMap[t.id] = 0; });
    matches.forEach(match => {
      if (match.status === 'completed' && match.scoreHome !== null && match.scoreAway !== null) {
        if (match.scoreHome > match.scoreAway) winsMap[match.homeTeamId] = (winsMap[match.homeTeamId] || 0) + 1;
        else if (match.scoreAway > match.scoreHome) winsMap[match.awayTeamId] = (winsMap[match.awayTeamId] || 0) + 1;
      }
    });
    let topTeamName = 'Sin datos'; let maxWins = 0;
    teams.forEach(t => {
      const wins = winsMap[t.id] || 0;
      if (wins > maxWins) { maxWins = wins; topTeamName = t.name; }
    });
    return { ...league, teamsCount: teams.length, topTeamName: maxWins > 0 ? topTeamName : 'Sin definir', topTeamWins: maxWins };
  }));
  statsContainer.innerHTML = `
    <article class="info-card">
      <header class="info-card__header">
        <h3 class="info-card__label league-stats-header">Equipos Registrados vs. Líder en Victorias por Liga</h3>
      </header>
      <div class="chart-wrapper chart-container">
        <canvas id="canvas-league-stats"></canvas>
      </div>
    </article>`;
  renderLeagueStatsChart('canvas-league-stats', leaguesDataWithTopWins);
}

async function renderLeaguesCards(leagues, activeLeague) {
  const grid = document.getElementById('leagues-grid');
  if (!grid) return;
  if (leagues.length === 0) {
    const sportName = SPORT_DISPLAY_NAMES[getActiveSport()] || 'este deporte';
    grid.innerHTML = `
      <div class="empty-state">
        <p class="empty-state__title">No hay ligas de ${sportName} registradas.</p>
        <p class="empty-state__subtitle">Presiona "+ Crear Nueva Liga" para empezar tu torneo.</p>
      </div>`;
    return;
  }
  const cardsHTML = await Promise.all(leagues.map(async (league) => {
    const isActive = activeLeague && activeLeague.id === league.id;
    const teams = await getTeamsByLeague(league.id);
    const matches = await getMatchesByLeague(league.id);
    const safeName = escapeHTML(league.name);
    const displaySportName = SPORT_DISPLAY_NAMES[league.sport] || league.sport || 'Fútbol';
    const safeSport = escapeHTML(displaySportName);
    const safeSeason = escapeHTML(league.season || '2026');
    const safeMode = escapeHTML(league.mode);
    const safeDescription = escapeHTML(league.description);
    const safeId = escapeHTML(league.id);
    let hasPlayers = true;
    if (teams.length > 0) {
      for (const team of teams) {
        const players = await getPlayersByTeam(team.id);
        if (players.length === 0) { hasPlayers = false; break; }
      }
    } else { hasPlayers = false; }
    const allMatchesPlayed = matches.length > 0 && matches.every(m => m.status === 'completed');
    const hasStartedPlaying = matches.some(m => m.status === 'completed');
    const isGuest = league.role === 'guest';
    const isLigaMode = league.mode.includes('Liga');
    let requiredTeams = 2;
    if (!isLigaMode) {
      if (league.mode.includes('4')) requiredTeams = 4;
      else if (league.mode.includes('8')) requiredTeams = 8;
      else if (league.mode.includes('16')) requiredTeams = 16;
    }
    const meetsTeamRequirements = isLigaMode ? (teams.length >= requiredTeams) : (teams.length === requiredTeams);
    const canExport = meetsTeamRequirements && hasPlayers;
    let primaryActionBtn = '';
    let secondaryActionBtn = '';
    if (isGuest) {
      primaryActionBtn = `<button class="btn btn--primary btn--sm btn-guest-update" data-id="${safeId}"><i class="fa-solid fa-arrows-rotate"></i> Actualizar</button>`;
      secondaryActionBtn = '<div></div>';
    } else {
      if (league.isFinished) {
        primaryActionBtn = '<span class="league-status-finished"><i class="fa-solid fa-flag-checkered"></i> FINALIZADA</span>';
        secondaryActionBtn = '<div></div>';
      } else if (allMatchesPlayed) {
        primaryActionBtn = `<button class="btn btn--primary btn--sm btn-final-results" data-id="${safeId}"><i class="fa-solid fa-trophy"></i> Finalizar</button>`;
        secondaryActionBtn = '<div></div>';
      } else {
        if (canExport) {
          primaryActionBtn = `<button class="btn btn--secondary btn--sm btn-export-league" data-id="${safeId}"><i class="fa-solid fa-cloud-arrow-up"></i> Exportar</button>`;
        } else {
          let reason = !meetsTeamRequirements ? `Faltan equipos (Req: ${requiredTeams})` : 'Los equipos deben tener al menos 1 jugador (capitán)';
          primaryActionBtn = `<button class="btn btn--secondary btn--sm league-status-locked" disabled title="${reason}"><i class="fa-solid fa-lock"></i> Bloqueado</button>`;
        }
        if (hasStartedPlaying) {
          secondaryActionBtn = `<button class="btn btn--secondary btn--sm btn-export-update" data-id="${safeId}"><i class="fa-solid fa-cloud-arrow-up"></i> Sync</button>`;
        } else {
          secondaryActionBtn = '<div></div>';
        }
      }
    }
    let importTeamsBtn = '';
    if (!isGuest && !allMatchesPlayed && matches.length === 0) {
      importTeamsBtn = `<button class="btn btn--secondary btn--sm btn-import-teams" data-id="${safeId}"><i class="fa-solid fa-camera"></i> Importar</button>`;
    } else {
      importTeamsBtn = '<div></div>';
    }
    return `
      <article class="league-card ${isActive ? 'league-card--active' : ''}">
        <span class="league-card__role ${isGuest ? 'league-card__role--guest' : 'league-card__role--owner'}">
          ${isGuest ? 'INVITADO' : 'PROPIETARIO'}
        </span>
        <header class="league-card__header">
          <div class="league-card__meta">
            <span class="league-card__badge">${safeSport}</span>
            <span class="league-card__season">${safeSeason}</span>
          </div>
          <h2 class="league-card__title">${safeName}</h2>
        </header>
        <div class="league-card__body">
          <p><strong>Modalidad:</strong> ${safeMode}</p>
          <p><strong>Equipos:</strong> ${teams.length} ${!isGuest && !meetsTeamRequirements ? `<span class="league-req-warning">(Req: ${requiredTeams})</span>` : ''}</p>
          <p><strong>Partidos:</strong> ${matches.length}</p>
          ${safeDescription ? `<p class="league-card__description">"${safeDescription}"</p>` : ''}
        </div>
        <footer class="league-card__footer">
          <div class="league-card__actions">
            ${isActive 
              ? '<span class="league-card__active-label"><i class="fa-solid fa-circle-check"></i> LIGA ACTIVA</span>' 
              : `<button class="btn btn--secondary btn--sm btn-set-active" data-id="${safeId}"><i class="fa-solid fa-circle-check"></i> Activar</button>`
            }
            ${!isGuest ? `<button class="btn btn--secondary btn--sm btn-edit-league" data-id="${safeId}"><i class="fa-solid fa-pen"></i> Editar</button>` : '<div></div>'}
            ${!isGuest ? `<button class="btn btn--primary btn--sm btn-gen-fixture" data-id="${safeId}" data-mode="${safeMode}" data-teams="${teams.length}"><i class="fa-solid fa-bolt"></i> Partidos</button>` : '<div></div>'}
            ${importTeamsBtn}
            ${primaryActionBtn}
            ${secondaryActionBtn}
            <button class="btn btn--sm btn-danger btn-delete-league" data-id="${safeId}"><i class="fa-solid fa-trash"></i> Borrar</button>
            ${isGuest ? '<div></div>' : ''} 
          </div>
        </footer>
      </article>`;
  }));
  grid.innerHTML = cardsHTML.join('');
  setupCardEvents(leagues);
}

function setupModalEvents(leagues) {
  const modal = document.getElementById('league-modal');
  const btnOpen = document.getElementById('btn-open-create-modal');
  const btnClose = document.getElementById('btn-close-modal');
  const form = document.getElementById('league-form');
  const modalTitle = document.getElementById('modal-title');
  const sportSelect = document.getElementById('league-sport');
  const modeSelect = document.getElementById('league-mode');
  btnOpen?.addEventListener('click', () => {
    form.reset();
    document.getElementById('league-id').value = '';
    modalTitle.textContent = 'Crear Nueva Liga';
    sportSelect.value = getActiveSport();
    sportSelect.disabled = true; 
    modeSelect.disabled = false;
    modal.classList.remove('is-hidden');
  });
  btnClose?.addEventListener('click', () => modal.classList.add('is-hidden'));
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('league-id').value;
    const name = document.getElementById('league-name').value.trim();
    const season = document.getElementById('league-season').value.trim();
    const durationDays = document.getElementById('league-duration').value;
    const description = document.getElementById('league-description').value.trim();
    const isDuplicate = leagues.some(l => l.name.toLowerCase() === name.toLowerCase() && l.id !== id);
    if (isDuplicate) { AlertService.showWarning(`Ya existe una liga con el nombre "${name}".`, 'NOMBRE EN USO'); return; }
    try {
      if (id) {
        const targetLeague = leagues.find(l => l.id === id);
        if (targetLeague) {
          const updatedData = { ...targetLeague, name, season, durationDays: Number(durationDays), description };
          if (typeof updateLeague === 'function') { await updateLeague(updatedData); AlertService.showSuccess('Liga actualizada correctamente.'); }
        }
      } else {
        const sport = sportSelect.value; 
        const mode = modeSelect.value;
        const createdLeague = await createLeague({ name, sport, season, mode, durationDays: Number(durationDays), description, isActive: true });
        localStorage.setItem('active_sport_id', sport);
        if (createdLeague && createdLeague.id) localStorage.setItem('caimanada_active_league', createdLeague.id);
        AlertService.showChampion('¡Liga creada y activada con éxito!', '¡NUEVO TORNEO!');
      }
      modal.classList.add('is-hidden');
      await renderLeaguesView();
    } catch (err) {
       AlertService.showError('No se pudo guardar la liga en la base de datos.');
    }
  });
}

function setupCardEvents(leagues) {
  const container = document.getElementById('leagues-grid');
  if (!container) return;
  container.addEventListener('click', async (e) => {
    const target = e.target;
    const leagueId = target.dataset.id;
    if (!leagueId) return;
    const league = leagues.find(l => l.id === leagueId);
    if (target.classList.contains('btn-set-active')) {
      await setActiveLeague(leagueId);
      localStorage.setItem('caimanada_active_league', leagueId);
      if (league && league.sport) localStorage.setItem('active_sport_id', league.sport);
      AlertService.showSuccess(`Liga ${league.name} activada.`, 'LIGA ACTIVA');
      setTimeout(() => window.location.hash = '#dashboard', 800);
      return;
    }
    if (target.classList.contains('btn-import-teams')) { openImportTeamScanner(league); return; }
    if (target.classList.contains('btn-export-league')) { if (league) openShareLeagueModal(league, 'initial'); return; }
    if (target.classList.contains('btn-export-update')) { if (league) openShareLeagueModal(league, 'update'); return; }
    if (target.classList.contains('btn-final-results')) { if (league) openFinalResultsModal(league); return; }
    if (target.classList.contains('btn-guest-update')) { openGuestUpdateScanner(league); return; }
    if (target.classList.contains('btn-gen-fixture')) { const mode = target.dataset.mode; handleGenerateFixture(league, mode); return; }
    if (target.classList.contains('btn-edit-league')) {
      if (!league) return;
      document.getElementById('league-id').value = league.id;
      document.getElementById('league-name').value = league.name;
      document.getElementById('league-season').value = league.season || '';
      document.getElementById('league-duration').value = league.durationDays || 7;
      document.getElementById('league-description').value = league.description || '';
      const sportSelect = document.getElementById('league-sport');
      const modeSelect = document.getElementById('league-mode');
      sportSelect.value = league.sport; modeSelect.value = league.mode;
      sportSelect.disabled = true; modeSelect.disabled = true;
      document.getElementById('modal-title').textContent = 'Editar Liga';
      document.getElementById('league-modal').classList.remove('is-hidden');
      return;
    }
    if (target.classList.contains('btn-delete-league')) {
      showConfirmDialog(`¿Estás seguro de que deseas eliminar la liga <strong>"${escapeHTML(league.name)}"</strong>?<br><br>ESTA ACCIÓN BORRARÁ TODOS SUS EQUIPOS Y PARTIDOS ASOCIADOS.`,
        async () => {
          try {
            await deleteLeague(leagueId);
            const remainingLeagues = await getAllLeagues();
            if (remainingLeagues.length > 0) {
              const hasActive = remainingLeagues.some(l => l.isActive);
              if (!hasActive) {
                const nextLeague = remainingLeagues[0];
                await setActiveLeague(nextLeague.id);
                localStorage.setItem('caimanada_active_league', nextLeague.id);
                localStorage.setItem('active_sport_id', nextLeague.sport || 'futbol_sala');
              }
            } else { localStorage.removeItem('caimanada_active_league'); }
            AlertService.showWarning('Liga eliminada correctamente.', 'LIGA BORRADA');
            renderLeaguesView();
          } catch (err) { AlertService.showError('Error al eliminar la liga.'); }
        }
      );
    }
  });
}

function showConfirmDialog(messageHTML, onConfirmCallback) {
  document.getElementById('dynamic-confirm-modal')?.remove();
  const modalHTML = `
    <div id="dynamic-confirm-modal" class="modal-overlay">
      <div class="modal-card modal-card--confirm">
        <h2 class="modal-card__title">Confirmar Acción</h2>
        <p class="modal-subtitle">${messageHTML}</p>
        <div class="modal-actions">
          <button type="button" id="dyn-confirm-cancel" class="btn btn--secondary">Cancelar</button>
          <button type="button" id="dyn-confirm-accept" class="btn btn--danger"><i class="fa-solid fa-trash"></i> Sí, Eliminar</button>
        </div>
      </div>
    </div>`;
  document.body.insertAdjacentHTML('beforeend', modalHTML);
  const modalEl = document.getElementById('dynamic-confirm-modal');
  document.getElementById('dyn-confirm-cancel').onclick = () => modalEl.remove();
  modalEl.onclick = (e) => { if (e.target === modalEl) modalEl.remove(); };
  document.getElementById('dyn-confirm-accept').onclick = async () => { modalEl.remove(); if (onConfirmCallback) await onConfirmCallback(); };
}

function openImportLeagueModal() {
  document.getElementById('dynamic-import-league-modal')?.remove();
  const modalHTML = `
    <div id="dynamic-import-league-modal" class="modal-overlay">
      <div class="modal-card modal-card--form">
        <h2 class="modal-card__title">Importar Liga</h2>
        <p class="modal-subtitle">Escanea el código QR inicial de la liga (o de actualización) o sube el archivo JSON que te envió el organizador.</p>
        <div class="qr-display-box">
          <button id="btn-scan-league-qr" class="btn btn--primary btn-full"><i class="fa-solid fa-qrcode"></i> Escanear QR de Liga</button>
          <div class="upload-divider">- O -</div>
          <button id="btn-upload-league-json" class="btn btn--secondary btn-full"><i class="fa-solid fa-file-arrow-up"></i> Subir Archivo JSON</button>
          <input type="file" id="league-json-input" accept=".json" class="is-hidden">
          <div id="qr-league-video-container" class="qr-video-container is-hidden">
            <video id="qr-league-video" autoplay muted playsinline></video>
          </div>
        </div>
        <div class="modal-actions form-flex--end">
          <button type="button" id="dyn-import-league-cancel" class="btn btn--secondary">Cancelar</button>
        </div>
      </div>
    </div>`;
  document.body.insertAdjacentHTML('beforeend', modalHTML);
  const modalEl = document.getElementById('dynamic-import-league-modal');
  const videoEl = document.getElementById('qr-league-video');
  const videoContainer = document.getElementById('qr-league-video-container');
  const fileInput = document.getElementById('league-json-input');
  document.getElementById('dyn-import-league-cancel').onclick = () => { stopQRScanner(); modalEl.remove(); };
  document.getElementById('btn-scan-league-qr').onclick = async () => {
    videoContainer.classList.remove('is-hidden');
    await startQRScanner(videoEl, async (rawData) => {
      try {
        const result = await handleImportData(rawData);
        if (result.success) {
          if (result.league && result.league.sport) {
            localStorage.setItem('active_sport_id', result.league.sport);
            const sportSelect = document.getElementById('active-sport-selector');
            if (sportSelect) sportSelect.value = result.league.sport;
          }
          AlertService.showChampion(result.message || '¡Liga importada/actualizada!', '¡SINCRONIZADO!');
          stopQRScanner();
          modalEl.remove();
          renderLeaguesView(); 
        }
      } catch (err) {
        AlertService.showError(err.message, 'ERROR DE QR');
        stopQRScanner();
        videoContainer.classList.add('is-hidden');
      }
    }, (err) => { AlertService.showError('No se pudo acceder a la cámara. Usa Subir JSON en su lugar.', 'ERROR DE CÁMARA'); });
  };
  document.getElementById('btn-upload-league-json').onclick = () => fileInput.click();
  fileInput.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const result = await importLeagueFromJsonFile(file);
      if (result.success) {
        AlertService.showChampion(result.message || '¡Liga importada!', '¡LIGA IMPORTADA!');
        modalEl.remove();
        renderLeaguesView(); 
      }
    } catch (err) { AlertService.showError(err.message, 'ERROR DE ARCHIVO'); }
  };
}

function openImportTeamScanner(leagueData) {
  document.getElementById('dynamic-import-modal')?.remove();
  const modalHTML = `
    <div id="dynamic-import-modal" class="modal-overlay">
      <div class="modal-card modal-card--form">
        <h2 class="modal-card__title">Importar Equipos a ${escapeHTML(leagueData.name)}</h2>
        <p class="modal-subtitle">Pide a cada capitán que abra el QR de su equipo y apunta la cámara aquí. Puedes escanear varios seguidos.</p>
        <div class="qr-video-container">
          <video id="qr-import-video" autoplay muted playsinline></video>
        </div>
        <div class="modal-actions form-flex--end">
          <button type="button" id="dyn-import-cancel" class="btn btn--secondary">Finalizar Importación</button>
        </div>
      </div>
    </div>`;
  document.body.insertAdjacentHTML('beforeend', modalHTML);
  const modalEl = document.getElementById('dynamic-import-modal');
  const videoEl = document.getElementById('qr-import-video');
  document.getElementById('dyn-import-cancel').onclick = async () => { stopQRScanner(); modalEl.remove(); renderLeaguesView(); };
  const handleScanSuccess = async (rawData) => {
    try {
      let parsed = JSON.parse(rawData);
      if (parsed.app !== 'Caimanada' || parsed.type !== 'IMPORT_TEAM') { throw new Error('Este QR no pertenece a un equipo.'); }
      parsed.payload.leagueId = leagueData.id;
      const result = await handleImportData(JSON.stringify(parsed));
      if (result.success) {
        AlertService.showSuccess(result.message, 'EQUIPO AÑADIDO');
        stopQRScanner(); 
        setTimeout(() => {
          if (document.getElementById('dynamic-import-modal')) {
            startQRScanner(videoEl, handleScanSuccess, (err) => { AlertService.showError('No se pudo reanudar la cámara.', 'ERROR DE CÁMARA'); modalEl.remove(); });
          }
        }, 1500);
      }
    } catch (err) { AlertService.showError(err.message, 'ERROR DE QR'); stopQRScanner(); modalEl.remove(); }
  };
  startQRScanner(videoEl, handleScanSuccess, (err) => { AlertService.showError('No se pudo acceder a la cámara.', 'ERROR DE CÁMARA'); modalEl.remove(); });
}

async function openShareLeagueModal(leagueData, exportType) {
  document.getElementById('dynamic-share-modal')?.remove();
  const titleText = exportType === 'update' ? 'Exportar Actualización' : 'Exportar Liga Inicial';
  const subtitleText = exportType === 'update' ? 'Genera este QR después de cada jornada para que los invitados actualicen sus resultados.' : 'Genera este QR solo cuando todos los equipos estén registrados con sus jugadores.';
  const modalHTML = `
    <div id="dynamic-share-modal" class="modal-overlay">
      <div class="modal-card modal-card--form">
        <h2 class="modal-card__title">${titleText}</h2>
        <p class="modal-subtitle">${subtitleText}</p>
        <div class="qr-display-box">
          <button id="btn-show-qr" class="btn btn--primary btn-full"><i class="fa-solid fa-qrcode"></i> Generar Código QR</button>
          <div id="qr-display-container" class="qr-image-container is-hidden">
            <div class="qr-white-box">
              <img id="qr-image" src="" alt="Código QR" />
            </div>
            <p class="qr-caption">Escanea para sincronizar</p>
          </div>
        </div>
        <div class="modal-actions form-flex--end">
          <button type="button" id="dyn-share-cancel" class="btn btn--secondary">Cerrar</button>
        </div>
      </div>
    </div>`;
  document.body.insertAdjacentHTML('beforeend', modalHTML);
  const modalEl = document.getElementById('dynamic-share-modal');
  document.getElementById('dyn-share-cancel').onclick = () => modalEl.remove();
  document.getElementById('btn-show-qr').onclick = async () => {
    const matches = await getMatchesByLeague(leagueData.id);
    let payload = { leagueId: leagueData.id, leagueName: leagueData.name, sport: leagueData.sport, mode: leagueData.mode };
    if (exportType === 'initial') {
      const teams = await getTeamsByLeague(leagueData.id);
      const teamsWithPlayers = await Promise.all(teams.map(async (t) => {
        const players = await getPlayersByTeam(t.id);
        return { id: t.id, name: t.name, sportId: t.sportId, delegate: t.delegate, color: t.color, players: players.map(p => ({ id: p.id, name: p.name, number: p.number, position: p.position })) };
      }));
      payload.teams = teamsWithPlayers;
      payload.matches = matches.map(m => ({ id: m.id, status: m.status, scoreHome: m.scoreHome, scoreAway: m.scoreAway, homeTeamId: m.homeTeamId, awayTeamId: m.awayTeamId, date: m.date, round: m.round || 1, slot: m.slot || null, winnerGoesToMatchId: m.winnerGoesToMatchId }));
    } else {
      payload.matches = await Promise.all(matches.map(async (m) => {
        const events = m.status === 'completed' ? await MatchEventRepository.getEventsByMatch(m.id) : [];
        return { id: m.id, status: m.status, scoreHome: m.scoreHome, scoreAway: m.scoreAway, events: events || [] };
      }));
    }
    const qrPayload = buildQRPayload(exportType === 'update' ? 'LEAGUE_UPDATE' : 'LINK_LEAGUE', payload);
    const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(qrPayload)}`;
    document.getElementById('qr-image').src = qrApiUrl;
    document.getElementById('qr-display-container').classList.remove('is-hidden');
  };
}

async function openFinalResultsModal(leagueData) {
  document.getElementById('dynamic-share-modal')?.remove();
  const modalHTML = `
    <div id="dynamic-share-modal" class="modal-overlay">
      <div class="modal-card modal-card--form">
        <h2 class="modal-card__title">Última Sincronización</h2>
        <p class="modal-subtitle">Genera este QR para que los invitados actualicen los resultados y estadísticas finales de la liga.</p>
        <div class="qr-display-box">
          <button id="btn-show-qr" class="btn btn--primary btn-full"><i class="fa-solid fa-qrcode"></i> Generar Código QR Final</button>
          <div id="qr-display-container" class="qr-image-container is-hidden">
            <div class="qr-white-box">
              <img id="qr-image" src="" alt="Código QR" />
            </div>
            <p class="qr-caption">Escanea para sincronizar</p>
          </div>
        </div>
        <div class="modal-actions form-flex--end">
          <button type="button" id="dyn-share-cancel" class="btn btn--secondary">Cerrar</button>
        </div>
      </div>
    </div>`;
  document.body.insertAdjacentHTML('beforeend', modalHTML);
  const modalEl = document.getElementById('dynamic-share-modal');
  document.getElementById('dyn-share-cancel').onclick = async () => { modalEl.remove(); await renderLeaguesView(); };
  document.getElementById('btn-show-qr').onclick = async () => {
    const matches = await getMatchesByLeague(leagueData.id);
    let payload = { leagueId: leagueData.id, leagueName: leagueData.name, sport: leagueData.sport, mode: leagueData.mode };
    payload.matches = await Promise.all(matches.map(async (m) => {
      const events = m.status === 'completed' ? await MatchEventRepository.getEventsByMatch(m.id) : [];
      return { id: m.id, status: m.status, scoreHome: m.scoreHome, scoreAway: m.scoreAway, events: events || [] };
    }));
    const qrPayload = buildQRPayload('LEAGUE_UPDATE', payload);
    const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(qrPayload)}`;
    document.getElementById('qr-image').src = qrApiUrl;
    document.getElementById('qr-display-container').classList.remove('is-hidden');
    if (!leagueData.isFinished) { await updateLeague({ ...leagueData, isFinished: true }); }
  };
}

function openGuestUpdateScanner(league) {
  document.getElementById('dynamic-guest-scan-modal')?.remove();
  const modalHTML = `
    <div id="dynamic-guest-scan-modal" class="modal-overlay">
      <div class="modal-card modal-card--form">
        <h2 class="modal-card__title">Actualizar Liga</h2>
        <p class="modal-subtitle">Pide al organizador que te muestre el QR de Actualización o Resultados Finales y escanéalo aquí.</p>
        <div class="qr-video-container">
          <video id="qr-guest-video" autoplay muted playsinline></video>
        </div>
        <div class="modal-actions form-flex--end">
          <button type="button" id="dyn-guest-scan-cancel" class="btn btn--secondary">Cancelar</button>
        </div>
      </div>
    </div>`;
  document.body.insertAdjacentHTML('beforeend', modalHTML);
  const modalEl = document.getElementById('dynamic-guest-scan-modal');
  const videoEl = document.getElementById('qr-guest-video');
  document.getElementById('dyn-guest-scan-cancel').onclick = () => { stopQRScanner(); modalEl.remove(); };
  startQRScanner(videoEl, async (rawData) => {
    try {
      const result = await handleImportData(rawData);
      if (result.success) {
        AlertService.showChampion(result.message, '¡SINCRONIZADO!');
        stopQRScanner(); modalEl.remove();
        renderLeaguesView();
      }
    } catch (err) { AlertService.showError(err.message, 'ERROR DE QR'); stopQRScanner(); }
  }, (err) => { AlertService.showError('No se pudo acceder a la cámara.', 'ERROR DE CÁMARA'); });
}

async function handleGenerateFixture(league, mode) {
  const isLiga = mode.includes('Liga');
  const isIdaYVuelta = mode.includes('Ida y vuelta');
  let requiredTeams = 2;
  if (!isLiga) {
    if (mode.includes('4')) requiredTeams = 4;
    else if (mode.includes('8')) requiredTeams = 8;
    else if (mode.includes('16')) requiredTeams = 16;
  }
  const teams = await getTeamsByLeague(league.id);
  const realTeamCount = teams.length;
  if (isLiga && realTeamCount < 2) { AlertService.showError('Se necesitan al menos 2 equipos para generar una Liga.'); return; }
  if (!isLiga && realTeamCount !== requiredTeams) { AlertService.showError(`Eliminación directa de ${requiredTeams} requiere EXACTAMENTE ${requiredTeams} equipos. Tienes ${realTeamCount}.`); return; }
  let generatedMatches = [];
  if (isLiga) generatedMatches = generateLeagueFixture(league.id, teams, isIdaYVuelta);
  else generatedMatches = generateEliminationBracket(league.id, teams, requiredTeams);
  openFixtureConfigModal(generatedMatches, teams, league);
}

function openFixtureConfigModal(matches, teamsList, leagueData) {
  document.getElementById('dynamic-fixture-modal')?.remove();
  const teamsObj = Object.fromEntries(teamsList.map(t => [t.id, t.name]));
  const leagueStart = new Date(leagueData.startDate);
  const leagueEnd = new Date(leagueData.endDate);
  const formatToLocalInput = (date) => {
    const d = new Date(date);
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 16);
  };
  const minDateStr = formatToLocalInput(leagueStart);
  const maxDateStr = formatToLocalInput(leagueEnd);
  let matchesHTML = '';
  matches.forEach((m, index) => {
    const homeName = m.homeTeamId === 'TBD' ? 'Por definir' : (teamsObj[m.homeTeamId] || 'Eliminado');
    const awayName = m.awayTeamId === 'TBD' ? 'Por definir' : (teamsObj[m.awayTeamId] || 'Eliminado');
    let dateVal = minDateStr;
    if (m.date) {
      const d = new Date(m.date);
      if (d >= leagueStart && d <= leagueEnd) { dateVal = formatToLocalInput(d); }
    }
    matchesHTML += `
      <div class="info-card fixture-item">
        <span class="fixture-team fixture-team--home">${homeName}</span>
        <span class="fixture-vs">VS</span>
        <span class="fixture-team fixture-team--away">${awayName}</span>
        <input type="datetime-local" class="form-control fixture-date-input" data-index="${index}" value="${dateVal}" min="${minDateStr}" max="${maxDateStr}" required />
      </div>`;
  });
  const startStr = leagueStart.toLocaleDateString('es-ES');
  const endStr = leagueEnd.toLocaleDateString('es-ES');
  const modalHTML = `
    <div id="dynamic-fixture-modal" class="modal-overlay">
      <div class="modal-card modal-card--fixture">
        <h2 class="modal-card__title">Organizar Calendario</h2>
        <p class="modal-subtitle">Ajusta las fechas y horas. Los partidos deben jugarse obligatoriamente entre el <strong>${startStr}</strong> y el <strong>${endStr}</strong>.</p>
        <div id="fixture-list-container">${matchesHTML}</div>
        <div class="modal-actions form-flex--end">
          <button type="button" id="btn-cancel-fixture" class="btn btn--secondary">Cancelar</button>
          <button type="button" id="btn-save-fixture" class="btn btn--primary"><i class="fa-solid fa-floppy-disk"></i> Guardar</button>
        </div>
      </div>
    </div>`;
  document.body.insertAdjacentHTML('beforeend', modalHTML);
  const modalEl = document.getElementById('dynamic-fixture-modal');
  document.getElementById('btn-cancel-fixture').onclick = () => modalEl.remove();
  modalEl.onclick = (e) => { if (e.target === modalEl) modalEl.remove(); };
  document.getElementById('btn-save-fixture').onclick = async () => {
    const dateInputs = document.querySelectorAll('.fixture-date-input');
    let isValid = true;
    dateInputs.forEach(input => {
      const idx = parseInt(input.dataset.index);
      if (input.value) {
        const chosenDate = new Date(input.value);
        if (chosenDate < leagueStart || chosenDate > leagueEnd) { isValid = false; } 
        else { matches[idx].date = chosenDate.toISOString(); }
      } else { isValid = false; }
    });
    if (!isValid) { AlertService.showError('Revisa las fechas. Todos los partidos deben tener una fecha válida dentro de la duración de la liga.'); return; }
    try {
      await bulkInsertFullMatches(matches);
      AlertService.showChampion(`¡Se guardaron ${matches.length} partidos exitosamente!`, 'FIXTURE LISTO');
      modalEl.remove();
      renderLeaguesView(); 
    } catch (error) {
      console.error('Error guardando fixture:', error);
      AlertService.showError('Ocurrió un error al guardar los partidos en la base de datos.');
    }
  };
}